// ============================================================
// Bajaj Finance AI Assistant — client-side UI logic
// Talks to the Flask backend (/api/*). No API key here.
// ============================================================

// ── State ──
let currentCustomer = null;
let pitchMade = false;

// ── Login ──
async function handleLogin(mobile) {
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mobile })
  });
  const data = await res.json();
  if (!data.success) return { ok: false, error: data.error };

  currentCustomer = data.customer;
  pitchMade = false;
  return { ok: true, data };
}

// ── Sidebar Rendering ──
function renderSidebar(data) {
  const accountsList = document.getElementById('accounts-list');
  accountsList.innerHTML = '';

  data.loans.forEach((c, idx) => {
    const div = document.createElement('div');
    div.className = `account-card${idx === 0 ? ' active' : ''}`;
    div.innerHTML = `
      <div class="account-type">${c.loanType}</div>
      <div class="account-lan">${c.LAN}</div>
      <div class="account-amount">${c.amountFormatted}</div>
      <div>
        <span class="account-status ${c.status.toLowerCase()}">
          <span class="status-dot ${c.status.toLowerCase()}"></span>
          ${c.status}
        </span>
      </div>
    `;
    div.onclick = () => {
      document.querySelectorAll('.account-card').forEach(el => el.classList.remove('active'));
      div.classList.add('active');
      const q = `Tell me about my ${c.loanType} account (${c.LAN}) — current balance, EMI and remaining tenure`;
      document.getElementById('user-input').value = q;
    };
    accountsList.appendChild(div);
  });

  if (data.eligibility) {
    const badge = document.getElementById('eligibility-badge');
    const tierColors = { Platinum: '#A855F7', Gold: '#FFB800', Silver: '#8892B0', Standard: '#4F78FF' };
    const tierEmojis = { Platinum: '💎', Gold: '🥇', Silver: '🥈', Standard: '📊' };
    const tier = data.eligibility.tier;
    const color = tierColors[tier] || '#4F78FF';
    badge.innerHTML = `
      <div class="eligibility-tier" style="color:${color}">${tierEmojis[tier] || '📊'} ${tier} Tier</div>
      <div class="eligibility-score">${data.eligibility.score} <span>/ 11 pts</span></div>
      <div class="eligibility-reasons">${data.eligibility.reasons.slice(0, 2).map(r => `✓ ${r}`).join('<br>')}</div>
    `;
  }

  document.getElementById('user-name-display').textContent = currentCustomer.firstName;
  document.getElementById('user-avatar-text').textContent = currentCustomer.initials;
}

// ── Welcome Message ──
function showWelcomeMessage(data) {
  const container = document.getElementById('messages');
  container.innerHTML = '';

  const msgDiv = document.createElement('div');
  msgDiv.className = 'message assistant';
  const now = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const firstName = currentCustomer.firstName;
  const loanCount = data.loans.length;

  msgDiv.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div>
      <div class="msg-bubble">
        <div class="welcome-card">
          <div class="welcome-greeting">👋 Hello, <span class="welcome-name">${firstName}!</span></div>
          <div class="welcome-text">
            I'm <strong>ARIA</strong>, your personal Bajaj Finance assistant. I have access to all your account details and I'm here to help.<br><br>
            You have <strong>${data.activeCount} active</strong> and <strong>${data.closedCount} closed</strong> loan account${loanCount > 1 ? 's' : ''} with us. What would you like to know?
          </div>
          <div class="welcome-chips">
            <span class="welcome-chip" onclick="sendMessage('What is my current EMI and outstanding balance?')">💰 EMI & Balance</span>
            <span class="welcome-chip" onclick="sendMessage('How many months are remaining on my active loan?')">📅 Remaining Tenure</span>
            <span class="welcome-chip" onclick="sendMessage('Show me my repayment status')">✅ Repayment Status</span>
            <span class="welcome-chip" onclick="sendMessage('Tell me about my loan interest rate')">📊 Interest Rate</span>
          </div>
        </div>
      </div>
      <div class="msg-time">${now}</div>
    </div>
  `;
  container.appendChild(msgDiv);

  setTimeout(() => {
    speak(`Hello ${firstName}! Welcome back to Bajaj Finance. I'm ARIA, your personal assistant. How can I help you today?`);
  }, 500);
}

// ── Quick Actions ──
function setupQuickButtons() {
  const btns = [
    { icon: '💰', text: 'EMI & Balance', query: 'What is my current EMI amount and outstanding balance?' },
    { icon: '📅', text: 'Tenure Remaining', query: 'How many months are remaining on my active loans?' },
    { icon: '✅', text: 'Repayment Status', query: 'What is my repayment status? Any missed payments?' },
    { icon: '📊', text: 'Loan Summary', query: 'Give me a complete summary of all my loan accounts' },
    { icon: '🏦', text: 'Interest Rate', query: 'What is the interest rate on my loans?' },
    { icon: '🤝', text: 'Mutual Funds', query: 'Tell me about Bajaj AMC mutual funds — which one would suit me?' },
  ];

  const container = document.getElementById('quick-btns');
  container.innerHTML = '';
  btns.forEach(b => {
    const btn = document.createElement('button');
    btn.className = 'quick-btn';
    btn.innerHTML = `<span>${b.icon}</span><span>${b.text}</span>`;
    btn.onclick = () => { sendMessage(b.query); };
    container.appendChild(btn);
  });
}

// ── Screen Transitions ──
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ── Chat UI ──
function addMessage(role, content) {
  const container = document.getElementById('messages');
  const msgDiv = document.createElement('div');
  msgDiv.className = `message ${role}`;

  const now = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const avatarEmoji = role === 'user' ? '👤' : '🤖';

  msgDiv.innerHTML = `
    <div class="msg-avatar">${avatarEmoji}</div>
    <div>
      <div class="msg-bubble">${formatMessageContent(content)}</div>
      <div class="msg-time">${now}</div>
    </div>
  `;

  container.appendChild(msgDiv);
  scrollToBottom();
  return msgDiv;
}

function formatMessageContent(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/### (.*?)(\n|$)/g, '<h3>$1</h3>')
    .replace(/## (.*?)(\n|$)/g, '<h3>$1</h3>')
    .replace(/\n\n/g, '<br><br>')
    .replace(/\n/g, '<br>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>');
}

function showTyping() {
  const container = document.getElementById('messages');
  const el = document.createElement('div');
  el.id = 'typing-indicator';
  el.className = 'typing-indicator message assistant';
  el.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="typing-dots">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>`;
  container.appendChild(el);
  scrollToBottom();
}

function hideTyping() {
  document.getElementById('typing-indicator')?.remove();
}

function scrollToBottom() {
  const c = document.getElementById('messages');
  c.scrollTop = c.scrollHeight;
}

function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ── Send Message ──
async function sendMessage(text) {
  if (!text.trim() || !currentCustomer) return;

  const inputEl = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  addMessage('user', escapeHtml(text));
  inputEl.value = '';
  inputEl.style.height = 'auto';
  sendBtn.disabled = true;

  showTyping();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text })
    });
    const data = await res.json();
    hideTyping();

    addMessage('assistant', data.reply);

    if (data.debug) updateDebugHUD(data.debug);

    if (data.pitch) {
      pitchMade = true;
      setTimeout(() => {
        const msgEl = addMessage('assistant', data.pitch.text);
        const fundCard = createFundCard(data.pitch.fund);
        msgEl.querySelector('.msg-bubble').appendChild(fundCard);
        speak(`${currentCustomer.firstName}, based on your excellent profile, I'd like to share a mutual fund opportunity that could help you build wealth alongside your existing loans. Would you like to know more?`);
      }, 800);
    }
  } catch (err) {
    hideTyping();
    addMessage('assistant', `❌ **Error:** ${err.message}\n\nPlease try again.`);
    console.error('Chat error:', err);
  }

  sendBtn.disabled = false;
}

// ── Fund Card ──
function createFundCard(fund) {
  const div = document.createElement('div');
  div.className = 'fund-pitch-card';
  div.innerHTML = `
    <div class="fund-pitch-header">
      <span style="font-size:1.4rem">${fund.emoji}</span>
      <div>
        <div class="fund-pitch-name">${fund.name}</div>
        <span class="fund-pitch-cat">${fund.category}</span>
      </div>
    </div>
    <div class="fund-pitch-reason">"${fund.reason}"</div>
    <div class="fund-pitch-stats">
      <div class="fund-stat">
        <div class="fund-stat-val">${fund.aum}</div>
        <div class="fund-stat-lbl">AUM</div>
      </div>
      <div class="fund-stat">
        <div class="fund-stat-val">${fund.expenseDirect}</div>
        <div class="fund-stat-lbl">Direct Expense</div>
      </div>
      <div class="fund-stat">
        <div class="fund-stat-val">${fund.riskLevel}</div>
        <div class="fund-stat-lbl">Risk</div>
      </div>
      <div class="fund-stat">
        <div class="fund-stat-val">${fund.minInvestment}</div>
        <div class="fund-stat-lbl">Min. SIP</div>
      </div>
    </div>
    <button class="fund-learn-btn" onclick="askAboutFund('${fund.name.replace(/'/g, "\\'")}')">Learn More →</button>
  `;
  return div;
}

function askAboutFund(fundName) {
  const input = document.getElementById('user-input');
  input.value = `Tell me more about the ${fundName} — what are its key features and is it suitable for me?`;
  input.focus();
}

// ── Voice Integration (Web Speech API — browser-native, unchanged) ──
let recognition = null;
let synthesis = window.speechSynthesis;
let currentUtterance = null;
let isSpeaking = false;
let isListening = false;

function initVoice() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn('Speech recognition not supported');
    document.getElementById('voice-btn').disabled = true;
    document.getElementById('voice-btn').title = 'Voice not supported in this browser';
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'en-IN';

  recognition.onstart = () => { isListening = true; updateVoiceUI('listening'); };

  recognition.onresult = (e) => {
    const transcript = Array.from(e.results).map(r => r[0].transcript).join('');
    const input = document.getElementById('user-input');
    input.value = transcript;
    if (e.results[e.results.length - 1].isFinal) {
      isListening = false;
      updateVoiceUI('idle');
      if (transcript.trim()) {
        setTimeout(() => sendMessage(transcript), 300);
      }
    }
  };

  recognition.onerror = (e) => {
    console.error('Voice error:', e.error);
    isListening = false;
    updateVoiceUI('idle');
  };

  recognition.onend = () => {
    if (isListening) { isListening = false; updateVoiceUI('idle'); }
  };
}

function toggleListening() {
  if (!recognition) { alert('Voice recognition not available in this browser. Try Chrome or Edge.'); return; }
  if (isListening) {
    recognition.stop();
    isListening = false;
    updateVoiceUI('idle');
  } else {
    stopSpeaking();
    recognition.start();
  }
}

function speak(text) {
  if (!synthesis) return;
  stopSpeaking();

  const clean = text.replace(/\*\*/g, '').replace(/\*/g, '').replace(/[#]/g, '').replace(/\n/g, '. ').replace(/₹/g, 'rupees ').replace(/[→←]/g, '');

  currentUtterance = new SpeechSynthesisUtterance(clean);
  currentUtterance.lang = 'en-IN';
  currentUtterance.rate = 0.95;
  currentUtterance.pitch = 1.05;
  currentUtterance.volume = 0.9;

  const voices = synthesis.getVoices();
  const indianVoice = voices.find(v => v.lang === 'en-IN') || voices.find(v => v.lang.startsWith('en'));
  if (indianVoice) currentUtterance.voice = indianVoice;

  currentUtterance.onstart = () => { isSpeaking = true; updateVoiceUI('speaking'); };
  currentUtterance.onend = () => { isSpeaking = false; updateVoiceUI('idle'); };
  currentUtterance.onerror = () => { isSpeaking = false; updateVoiceUI('idle'); };

  synthesis.speak(currentUtterance);
}

function stopSpeaking() {
  if (synthesis && synthesis.speaking) {
    synthesis.cancel();
    isSpeaking = false;
    updateVoiceUI('idle');
  }
}

function updateVoiceUI(state) {
  const btn = document.getElementById('voice-btn');
  const status = document.getElementById('voice-status');

  btn.classList.remove('listening', 'speaking');
  status.classList.remove('show', 'speaking');

  if (state === 'listening') {
    btn.classList.add('listening');
    btn.innerHTML = '🔴';
    status.classList.add('show');
    status.innerHTML = `<div class="voice-wave">${'<div class="voice-bar"></div>'.repeat(5)}</div> Listening...`;
  } else if (state === 'speaking') {
    btn.classList.add('speaking');
    btn.innerHTML = '🔊';
    status.classList.add('show', 'speaking');
    status.innerHTML = `<div class="voice-wave">${'<div class="voice-bar"></div>'.repeat(5)}</div> Speaking...`;
  } else {
    btn.innerHTML = '🎤';
  }
}

// ── Debug HUD ──
let hudCollapsed = true;

function updateDebugHUD(debug) {
  document.getElementById('dbg-prompt-tokens').textContent = debug.promptTokens.toLocaleString();
  document.getElementById('dbg-completion-tokens').textContent = debug.completionTokens.toLocaleString();
  document.getElementById('dbg-total-tokens').textContent = debug.totalTokens.toLocaleString();
  document.getElementById('dbg-latency').textContent = `${debug.latency}ms`;
  document.getElementById('dbg-requests').textContent = debug.requestCount;
  document.getElementById('dbg-model').textContent = debug.model;
  document.getElementById('dbg-mf-score').textContent = debug.mfScoreTier;
  document.getElementById('dbg-turns').textContent = debug.questionCount;

  const latEl = document.getElementById('dbg-latency');
  latEl.className = 'debug-metric-value ' + (debug.latency < 2000 ? 'green' : debug.latency < 4000 ? 'gold' : 'red');

  if (debug.requestCount === 1 && hudCollapsed) {
    toggleDebugHUD();
  }
}

function toggleDebugHUD() {
  hudCollapsed = !hudCollapsed;
  const panel = document.getElementById('debug-panel');
  const arrow = document.getElementById('hud-arrow');
  panel.classList.toggle('collapsed', hudCollapsed);
  arrow.textContent = hudCollapsed ? '▲' : '▼';
}

// ── Main Init ──
async function init() {
  const input = document.getElementById('user-input');
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input.value);
    }
  });

  document.getElementById('send-btn').onclick = () => sendMessage(input.value);
  document.getElementById('voice-btn').onclick = toggleListening;
  document.getElementById('voice-btn').addEventListener('mousedown', () => {
    if (isSpeaking) stopSpeaking();
  });

  document.getElementById('debug-toggle').onclick = toggleDebugHUD;

  document.getElementById('logout-btn').onclick = async () => {
    await fetch('/api/logout', { method: 'POST' });
    currentCustomer = null;
    pitchMade = false;
    showScreen('login-screen');
    document.getElementById('login-mobile').value = '';
    document.getElementById('login-error').classList.remove('show');
  };

  document.getElementById('login-form').onsubmit = async (e) => {
    e.preventDefault();
    const mobile = document.getElementById('login-mobile').value.trim();
    const btn = document.getElementById('login-btn');
    const error = document.getElementById('login-error');

    btn.disabled = true;
    btn.textContent = 'Verifying...';
    error.classList.remove('show');

    const result = await handleLogin(mobile);
    if (result.ok) {
      renderSidebar(result.data);
      setupQuickButtons();
      showScreen('chat-screen');
      initVoice();
      setTimeout(() => showWelcomeMessage(result.data), 300);

      document.getElementById('dbg-model').textContent = result.data.model;
      document.getElementById('dbg-mf-score').textContent = `${result.data.eligibility.score} (${result.data.eligibility.tier})`;
    } else {
      error.textContent = `❌ ${result.error}`;
      error.classList.add('show');
    }

    btn.disabled = false;
    btn.textContent = 'Continue →';
  };

  document.getElementById('debug-panel').classList.add('collapsed');

  if (window.speechSynthesis) {
    window.speechSynthesis.onvoiceschanged = () => { /* voices loaded */ };
    window.speechSynthesis.getVoices();
  }
}

document.addEventListener('DOMContentLoaded', init);
